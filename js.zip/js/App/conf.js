
            //$('input[name="genderS"]:checked').val();
            var confApp = angular.module('confApp', []);

            // Define the `PhoneListController` controller on the `phonecatApp` module
          

    
    
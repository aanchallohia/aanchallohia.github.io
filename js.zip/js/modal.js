$(function(){
  console.log("modal loadeds");
});
//  $('#login').on('click',function(){
//      console.log("modal failed");
//            $('#modal-login').modal('show');
//            
//        });
//    $('#create').on('click',function(){
//        $('#modal-login').modal('hide')
//            $('#register-login').modal('show')
//        });
//$('#reg').on('click',function(){
//        $('#modal-login').modal('show')
//            $('#register-login').modal('hide')
//        });
//$( "#login" ).click(function() {
//  console.log("shdkuf");
//});
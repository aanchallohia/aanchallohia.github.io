$(function(){
  $("#nav").load("nav.html"); 
 console.log("loaded");
  $("#footer").load("footer.html"); 
});